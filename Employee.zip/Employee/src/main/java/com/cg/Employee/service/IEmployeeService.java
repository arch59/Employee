package com.cg.Employee.service;

import java.util.List;




import com.cg.Employee.entity.Employee;

public interface IEmployeeService {

	Employee addEmployee(Employee employee);

	List<Employee> readEmployee();

	Employee getEmp(String empId);

	Employee updateEmployee(String empId,Employee employee);


	Employee deleteEmployee(String empId);

	Employee updateEmployee1(String name, Employee employee);


}
