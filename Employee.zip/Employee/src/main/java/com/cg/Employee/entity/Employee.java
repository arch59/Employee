package com.cg.Employee.entity;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;
@Document
public class Employee {
	@Id
	private String empId;
	private String name;
	private String pName;
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date startDate=new Date();
	Map<String,String> salary = new HashMap<>(); 
	public Map<String, String> getSalary() {
		return salary;
	}
	public void setSalary(Map<String, String> salary) {
		this.salary = salary;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Employee(String empId, String name, String pName, Date startDate,
			Map<String, String> salary) {
		super();
		this.empId = empId;
		this.name = name;
		this.pName = pName;
		this.startDate = startDate;
		this.salary = salary;
	}
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", pName="
				+ pName + ", startDate=" + startDate + ", salary=" + salary
				+ "]";
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	
	

}
