package com.cg.Employee.dao;

import java.util.List;






import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.Employee.entity.Employee;

@Repository
public class EmployeeDAOImpl implements IEmployeeDAO{
	
	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public Employee addEmployee(Employee employee) {
		mongoTemplate.save(employee);
		return employee;
	}

	@Override
	public List<Employee> readEmployee() {
		return mongoTemplate.findAll(Employee.class);	
	}
	
	@Override
	public Employee getEmp(String empId){
		Query query=new Query();
		query.addCriteria(Criteria.where("empId").is(empId));
		return mongoTemplate.findOne(query, Employee.class);
		
	}

	@Override
	public Employee updateEmployee(String empId,Employee employee) {
		Query query=new Query();
		query.addCriteria(Criteria.where("empId").is(employee.getEmpId()));
		employee.setEmpId(empId);
		mongoTemplate.findOne(query, Employee.class);
		mongoTemplate.save(employee);
		return employee;
	}

	@Override
	public Employee deleteEmployee(String empId) {
	Employee employee = getEmp(empId);
	if(employee!=null){
		
	
		 mongoTemplate.remove(employee);
	}
		 return employee;
	}

	@Override
	public Employee updateEmployee1(String name, Employee employee) {
		Query query=new Query();
		query.addCriteria(Criteria.where("name").is(name));
		
		mongoTemplate.findOne(query, Employee.class);
		mongoTemplate.save(employee);
		return employee;
	}
	}

	


