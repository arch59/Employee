package com.cg.Employee.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.Employee.entity.Employee;
import com.cg.Employee.service.IEmployeeService;

@RestController
@RequestMapping("/Employee")
public class EmpController {
	@Autowired
	private IEmployeeService employeeService;
	
	@RequestMapping(value="/create",method=RequestMethod.POST)
	public Employee addEmployee(@RequestBody Employee employee){
		return employeeService.addEmployee(employee);
	}
	@RequestMapping(value="/read",method=RequestMethod.GET)
	public List<Employee> readEmployee()
	{
		return employeeService.readEmployee();
	}
	@RequestMapping(value="/getEmp/{empId}",method=RequestMethod.GET)
	public Employee getEmployee(@PathVariable String empId){
		Employee employee=employeeService.getEmp(empId);
		return employee;
		
	}
	
	@RequestMapping(value="/update/{empId}",method=RequestMethod.PUT)
	public Employee updateEmployee(@RequestBody Employee employee,@PathVariable String empId)
	{
		return employeeService.updateEmployee(empId,employee);
	}
	@RequestMapping(value="/delete/{empId}",method=RequestMethod.DELETE)
	public Employee deleteEmployee(@PathVariable String empId)
	{
		return employeeService.deleteEmployee(empId);
	}
	
	@RequestMapping(value="/update1/{name}",method=RequestMethod.PUT)
	public Employee updateEmployee1(@RequestBody Employee employee,@PathVariable String name)
	{
		employee.setName(name);
		return employeeService.updateEmployee1(name,employee);
	}
	
	
}
