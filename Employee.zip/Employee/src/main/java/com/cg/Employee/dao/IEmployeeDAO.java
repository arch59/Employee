package com.cg.Employee.dao;

import java.util.List;

import com.cg.Employee.entity.Employee;

public interface IEmployeeDAO {
	
	public Employee addEmployee(Employee employee);

	public List<Employee> readEmployee();

	Employee getEmp(String empId);

	public Employee updateEmployee(String empId,Employee employee);

	public Employee deleteEmployee(String empId);

	public Employee updateEmployee1(String name, Employee employee);

}
